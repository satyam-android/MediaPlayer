package com.player.mediaplayer.constant;

import android.app.ExpandableListActivity;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ListView;

public interface localSongwidgetFromFragmentListner {
	public void onloadListView(ListView listview, EditText edit);
	public void onloadExpendableListViewArtist(ExpandableListView expList, EditText edit);
	public void onloadExpendableListViewAlbum(ExpandableListView expList, EditText edit);
	public void onloadExpendableListViewFolder(ExpandableListView expList, EditText edit);

}
