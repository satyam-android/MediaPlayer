package com.player.mediaplayer;

import com.player.SongsPod.R;

import android.app.Activity;
import android.os.Bundle;

public class downloadPlayActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.download_play_activity);
	}

}
