package com.player.mediaplayer.constant;

public interface nextSong {
	public void onNextSong(int i);
	public void afterSongComplete();

}
