package com.player.mediplayer.beans;

public class categoryBean {
	
	private String title;
	private String total_albums;
	private String albums_list;
	private String image_path;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTotal_albums() {
		return total_albums;
	}
	public void setTotal_albums(String total_albums) {
		this.total_albums = total_albums;
	}
	public String getAlbums_list() {
		return albums_list;
	}
	public void setAlbums_list(String albums_list) {
		this.albums_list = albums_list;
	}
	public String getImage_path() {
		return image_path;
	}
	public void setImage_path(String image_path) {
		this.image_path = image_path;
	}
	

}
