package com.player.mediaplayer.constant;

public class AppConstant {
	public static final int DATABASE = 0;
	public static final int SONG_TABLE = 1;
	public static final int INSERT_TABLE = 2;
	public static final int PLAY_STATE = 3;
	public static final int PAUSE_STATE = 4;
	
	public static final int NEXT = 5;
	public static final int PREV = 6;
	public static final int CROSS = 7;
	public static final int START_BIGINING = 8;

}
