package com.player.mediaplayer;

import com.player.SongsPod.R;

import android.app.Activity;
import android.os.Bundle;

public class about_us_activity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_us_activity);
	}

}
