package com.player.mediaplayer.constant;

public interface nextSong {
	void onNextSong(int i);
	void afterSongComplete();

}
