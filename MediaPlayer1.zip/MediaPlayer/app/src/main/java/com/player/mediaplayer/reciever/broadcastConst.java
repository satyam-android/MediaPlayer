package com.player.mediaplayer.reciever;

import com.player.mediaplayer.constant.AppConstant;

public class broadcastConst {
	public static int playerState = AppConstant.PAUSE_STATE;
	public static Boolean isPlayerFirstPlay = true;

}
