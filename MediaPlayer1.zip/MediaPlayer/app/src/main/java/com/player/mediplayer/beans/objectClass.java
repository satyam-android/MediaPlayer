package com.player.mediplayer.beans;

import android.app.Activity;

public class objectClass {
Activity act = null;
Object obj = null;
public Activity getAct() {
	return act;
}
public void setAct(Activity a) {
	this.act = a;
}
public Object getObj() {
	return obj;
}
public void setObj(Object obj) {
	this.obj = obj;
}

}
