package com.player.mediaplayer.constant;

public class jsonPath {
	public static String LATEST_ALBUM = "http://mp3jugaad.in/json-feeds/?feed=latest-albums";
	public static String TOP_SONGS = "http://mp3jugaad.in/json-feeds/?feed=top100";
	public static String SEARCH = "http://mp3jugaad.in/json-feeds/?feed=search&";//q=kick";
	public static String ACCOUNT_DETAIL = "http://mp3jugaad.in/json-feeds/record.php?";//imei=542136556032123&email=abc@gmail.com"
	//http://mp3jugaad.in/json-feeds/record.php?imei=542136556032123&email=abc@gmail.com&channel_id=apk1
	public static String CATEGORIES = "http://mp3jugaad.in/json-feeds/?feed=categories";
}
